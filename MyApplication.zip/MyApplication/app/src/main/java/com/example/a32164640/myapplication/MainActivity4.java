package com.example.a32164640.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity4 extends AppCompatActivity {

    ListView listView;

    int DRAWLINE = R.drawable.logo;
    String[] DESC = {"금천구 독산 1동", "시흥모터스", "아산역"};
    String[] HOWTO = {"도보5분", "8번버스", ""};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        CustomAdapter adapter = new CustomAdapter();
        listView.setAdapter(adapter);
    }

    public class CustomAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return DESC.length;
        }
        @Override
        public Object getItem(int i) {
            return null;
        }
        @Override
        public long getItemId(int i) {
            return 0;
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = getLayoutInflater().inflate(R.layout.custom4_layout, null);

            ImageView imageView = (ImageView)findViewById(R.id.drawLine);
            TextView textView = (TextView)findViewById(R.id.dest);
            TextView textView_plus = (TextView)findViewById(R.id.dest_plus);

            //해당 이미지삽입
            imageView.setImageResource(DRAWLINE);
            textView.setText(DESC[i]);
            textView_plus.setText(HOWTO[i]);

            return view;
        }
    }
}

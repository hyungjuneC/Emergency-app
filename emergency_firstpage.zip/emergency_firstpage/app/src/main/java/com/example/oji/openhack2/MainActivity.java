package com.example.oji.openhack2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView start_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String strFront = "가장 가까운 ";
        String strChange = "<font color=\"#ff2525\">응급실</font>";
        String strBack = " 찾기";
        TextView tv = (TextView)findViewById(R.id.intro);
        tv.setText(Html.fromHtml(strFront + strChange + strBack));

        start_button = (ImageView) findViewById(R.id.button_start);
        start_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "도보안내", Toast.LENGTH_LONG).show();


                Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                startActivity(intent);
            }
        });


    }

}


